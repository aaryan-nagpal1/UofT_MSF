%Now writing the code needed to get the error for the different levels of
%discretization mentioned in Q1f

function errorcalculator

%forming vectors for the n, J values and reference levels of discretization
nJ_values = [8,16,32,64];
reference = [512,512];

%getting the value of s_ref for comparison by passing to heat_fd_temp
ref_n = reference(1);
ref_J = reference(2);
s_ref = heat_fd_solver(ref_n, ref_J);
disp(s_ref)

%creating an error vector with zeros that holds the error values at each level of
%discretization we have above
error_values = zeros(length(nJ_values), size(nJ_values,1));

%obtaining the errors for each solution based on the parameters and storing
%them in the error_values vector we created earlier
for i = 1:length(nJ_values)
    s=heat_fd_solver(nJ_values(i),nJ_values(i));
    error_values(i)=abs(s_ref-s);
end

%Displaying the values in the form of a table to show the errors at each
%level of discretization
T=table(nJ_values',nJ_values',error_values, 'VariableNames', {'n','J','|s_ref-s|'});
disp(T)

end