function heat_fd_temp

% functions
gfun = @(x) 0.5*x.*(2-x) + 1/(6*pi)*sin(3*pi*x);
ffun = @(x,t) exp(-3*x).*exp(t);

% discretization parameters
n = 16;
J = 16;
T = 1; %over the time range (0,1) as given in the question

% setup spatial and temporal grids
xx = linspace(0,1,n+1)';
tt = linspace(0,T,J+1)';  %equally spaced points in the time domain
%discretization
dx = 1/n;
dt = T/J; %discretizing in the time domain over the given parameter

% assemble the A matrix
% (not the most effcient method, but it will work)
A = sparse([],[],[],n,n);
for i = 1:n
    if (i == 1) 
        % left boundary
        A(i,i) = 2;  %obtained from first element in first row of A matrix
        A(i,i+1) = -1; %obtained from second element in first row of A matrix
    elseif (i == n)
        % right boundary
        A(i,i-1) = -2; %obtained from second last element in last row of A matrix
        A(i,i) = 2+2*dx; %obtained from last element in last row of A matrix
    else
        % all other points
        % all these points are obtained from the 3 shifting elements in
        %each row of the A matrix except for the first and last rows which
        %represent the boundary conditions
        A(i,i-1) = -1; 
        A(i,i) = 2;
        A(i,i+1) = -1;
    end
end

%In my expression for the A matrix I also have a 1/dx^2 term in front of
%it, so I am adding that here for it to be consistent, once again using
%element wise division as A is a matrix!

A=A./dx^2;

% iteration
I = speye(n,n);

% assemble C and D matrices in terms of A, I, and dt
  %need to use elementwise division and multiplication as they are vector
  %representations of C and D
C = ((I./dt)+(1/2).*A);  %found in Q1c using C-N method
D = ((I./dt)-(1/2).*A);  %found in Q1c using C-N method

% initialize state
xxi = xx(2:end);  % x excluding the left node
U = gfun(xxi);

% record the initial state in UU; note the first node is left as 0
UU = zeros(n+1,J+1);
UU(2:end,1) = U; 
for j = 1:J    
    % evaluate F
    F = (1/2)*(ffun(xxi,tt(j))+ffun(xxi,tt(j+1))); %Using the expression we
    %found in Q1c but with indexing based on matlab formatting for the
    %steps in the function
    
    % solve linear system 
    % expression involves U, C, D, and F. Do NOT use "inv".
    %using the expression for U from Q1c, and also what was explained in
    %lecture and using \ instead of inv
    U = C\(F + D*UU(2:end,j));
    
    % record solution in UU
    UU(2:end,j+1) = U;
end 
% find time indices to plot
tplot = [0,1/16,1/8,1/4,1/2,1]';
[~,it] = intersect(tt,tplot);

% plot solution
figure(1), clf,
plot(xx,UU(:,it),'o-');
xlabel("Spatial Domain X-Values");
ylabel("u(x,t) Temperature Values");
legend("t=0", "t=1/16", "t=1/8", "t=1/4", "t=1/2", "t=1", 'Position', [0.2 0.6 0.1 0.2]);

% evaluate output
s = UU(end,end);

end
