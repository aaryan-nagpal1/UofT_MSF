%creating boundary values r_1, r_2 and also creating a vector with equally
%spaced points between them
r_1 = 1;
r_2 = 2;
r = linspace(r_1, r_2);

%creating a vector m for the two m values for which the solution will be
%graphed
m=[1,10];

%Plotting the solutions obtained by running the solver on the same plot
plot(r, usolver(r,m(1),r_1,r_2));
hold on
plot(r, usolver(r,m(2),r_1,r_2));
hold off

%labelling
xlabel('r');
ylabel('u(r,θ=0)');
title('Graph of u(r,θ=0) for m=1 and 10')
legend('m=1', 'm=10', 'Position', [0.2 0.6 0.1 0.2]);

function u = usolver(r,m,r_1,r_2)
%theta is 0 in the question
th = 0;
% Using the value of the solution we obtained in Q2b of the assignment
u = cos(m*th)*((r_1^(-2*m)*r.^m-(r.^(-m))))/(r_1^(-2*m)*r_2^m-(r_2^(-m)));
end