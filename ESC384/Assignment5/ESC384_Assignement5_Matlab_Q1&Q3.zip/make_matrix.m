function [Aint,interior] = make_matrix(xx,ldomain)
% Compute finite difference matrix for the Laplacian
% INPUT:
%   xx: grid coordinate
%   ldomain: boolean flag indicating whether to use L-domain
% OUTPUT:
%   A: finite difference matrix
%   interior: interior nodes in the xx array

% get number of 1d points assuming square grid
n1 = sqrt(size(xx,1));

% get grid spacing
%getting the spacing between 1d points assuming square grid by getting the 
%recirpocal obtained by subtracting the last point from the first
h = 1/(n1-1);

% construct a matrix for the n1 x n1 grid
n2 = n1*n1;
A = sparse([],[],[],n2,n2);
for i = 2:n1-1 % interior nodes only
    for j = 2:n1-1 % interior nodes only
        % fill the FD equation for node (i,j)
        
        % find single-index value of self and neighbors
        %using matlab indexing to get the index value of the required
        %variables listed below
        indc = i  + n1*(j-1);  % center node: (i,j)
        indl = i-1 + n1*(j-1);  % left node: (i-1,j)
        indr = i+1 + n1*(j-1);  % right node: (i+1,j)
        indb = i  + n1*(j-2);  % bottom node: (i,j-1)
        indt = i  + n1*(j);      % top node: (i,j+1)
        
        % fill values
        %setting the values for specific indices
        A(indc,indc) = 4/h^2;     % center value
        A(indc,indl) = -1/h^2;    % left value
        A(indc,indr) = -1/h^2;    % right value
        A(indc,indb) = -1/h^2;    % bottom value
        A(indc,indt) = -1/h^2;    % top value
    end
end

% we now find the interior nodes; these are the unknowns of the problem
if (ldomain)
    % the following line needs to be completed to extract the interior nodes of
    % the L-shaped domain
    interior = find(((xx(:,1) > 0) & (xx(:,1) < 1) & (xx(:,2) > 0) & (xx(:,2) < 1)) ...
        & ((xx(:,1) > 1/2) | (xx(:,2) < 1/2)));
else
    % the following line extracts the interior nodes of a square
    interior = find((xx(:,1) > 0) & (xx(:,1) < 1) & (xx(:,2) > 0) & (xx(:,2) < 1));
end

% extract the equations and unknowns associated with interior nodes
Aint = A(interior,interior);
end