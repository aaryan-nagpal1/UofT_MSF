function ldrum_c
ns = [1/8,1/16,1/32];
lambda1 = sqrt(2*pi^2);
lambda4 = sqrt(8*pi^2);

lambda1_error_values = zeros(length(ns),size(ns,1));
lambda4_error_values = zeros(length(ns),size(ns,1));
    

% number of grid spacings in each direction (i.e., 1/h)
hs = [8,16,32];

for i = 1:length(hs)
    ns1 = hs(i);
    disp(ns1)

    % specify the domain shape
    ldomain = false;
    
    % number of grid points in each direction
    n1 = ns1+1;
    n2 = n1*n1;
    
    % generates 2d grid points
    x1 = linspace(0,1,n1)';
    [xm,ym] = ndgrid(x1,x1);
    
    % concaternate grid points as single-index array
    xx = [xm(:),ym(:)]; 
    
    % construct a matrix for the n1 x n1 grid
    [Aint,interior] = make_matrix(xx,ldomain);
    
    % find the 10 smallest eigenvalues
    neig = 10;
    [V,D] = eigs(Aint,neig,'sm');
    
    % display the sqrt of the neig eigenvalues
    %fprintf('%.8e\n',sqrt(diag(D)));
    
    lambda1_error_values(i)=abs(lambda1-sqrt(D(1,1)));
    lambda4_error_values(i)=abs(lambda4-sqrt(D(4,4)));
end

T=table(hs',ns',lambda1_error_values, lambda4_error_values, 'VariableNames', {'ns','hs','|λ_1-ƛ_1|','|λ_4-ƛ_4|'});
disp(T)

% eigenfunction to be plotted; change this to plot different eigenfunctions
ieig = 4;  

% plotting style
use_pretty_plot = false;

% plot the specified eigenfunctions
U = zeros(n2,1);
U(interior) = V(:,ieig);
figure(1), clf,
if (use_pretty_plot)
    pretty_plot(xm,ym,U);
else
    regular_plot(xm,ym,U);
end

end

function regular_plot(xm,ym,U)
% regular plotting
if (sum(U) < 0)
    U = -U;
end
surf(xm,ym,reshape(U,size(xm)));  hold on;
shading interp;
view(0,90);
axis equal;
axis off;
axis([0,1,0,1]);
% plot the border
if (sum(abs(U(xm < 1/2 & ym > 1/2))) < 0.1)
   plot([0,1,1,1/2,1/2,0,0],[0,0,1,1,1/2,1/2,0],'k-'); 
end
end

function pretty_plot(xm,ym,U)
% Pretty plot for the L-shaped domain problem. 
% Copyright 1984-2007 The MathWorks, Inc.
% Modified by Masayuki Yano 2023
xm = 50*xm;
ym = 50*ym;
if (sum(U) < 0)
    U = -U;
end
U = U/max(abs(U));
if (min(U) < -0.01)
    Ushift = -0.4;
else
    Ushift = 0;
end
U = 40*(1/(max(U)-min(U))*(U-min(U)+Ushift));


figh = figure(1);
clf;
h = surf(ym,xm,reshape(U,size(xm))');
axis off;
logoax = axes('CameraPosition', [-193.4013 -265.1546  220.4819],...
    'CameraTarget',[26 26 10], ...
    'CameraUpVector',[0 0 1], ...
    'CameraViewAngle',9.5, ...
    'DataAspectRatio', [1 1 .9],...
    'Position',[0 0 1 1], ...
    'Visible','off', ...
    'XLim',[1 51], ...
    'YLim',[1 51], ...
    'ZLim',[-13 40], ...
    'parent',figh);
s = set(h, ...
    'EdgeColor','none', ...
    'FaceColor',[0.9 0.2 0.2], ...
    'FaceLighting','phong', ...
    'AmbientStrength',0.3, ...
    'DiffuseStrength',0.6, ...
    'Clipping','off',...
    'BackFaceLighting','lit', ...
    'SpecularStrength',1, ...
    'SpecularColorReflectance',1, ...
    'SpecularExponent',7, ...
    'parent',logoax);
l1 = light('Position',[40 100 20], ...
    'Style','local', ...
    'Color',[0 0.8 0.8], ...
    'parent',logoax);
l2 = light('Position',[.5 -1 .4], ...
    'Color',[0.8 0.8 0], ...
    'parent',logoax);
%z = zoom(figh);
%z.setAxes3DPanAndZoomStyle(logoax,'camera');
end