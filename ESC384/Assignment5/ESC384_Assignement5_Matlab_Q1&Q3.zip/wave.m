function wave

% number of grid spacings in each direction (i.e., 1/h)
ns1 = 128;

% number of grid points in each direction
n1 = ns1 + 1;
n2 = n1 * n1;

% generates 2d grid points
x1 = linspace(0, 1, n1)';
[xm, ym] = ndgrid(x1, x1);

% concaternate grid points as single-index array
xx = [xm(:), ym(:)];

% construct the Laplacian matrix for the n1 x n1 square grid
[Aint, interior] = make_matrix(xx, false);
n = size(Aint, 1);

% load initial condition
d = load('ic.mat');
W = [d.U0; d.V0]; % concatenate displacement and velocity as a single vector

% useful matrices
Iint = speye(size(Aint)); % sparse identity matrix for interior points
Zint = sparse([], [], [], n, n); % sparse zero matrix for interior points

% set time step
dt = 0.005;

%creating the identity matrix with dimensions to match W (a vector with
%u,v)
Iint2 = speye(size([Zint Iint; -Aint Zint]));

%creating the B matrix using the expression found for it in Q3 part (a)
B = [Zint Iint; -Aint Zint];

%creating the timestamps at which we want to observe the plotted solution
timestamps =[0,0.15,0.3];

% time marching
for it = 1:n1
    % Crank-Nicolson update
    W = (Iint2-dt/2.*B)\((dt/2.*B+Iint2)*W); %the update the uses the identity matrix with
    %dimensions equivalent to W and the B matrix whihc was setup as
    %earlier, the expression for W was also obtained in Q3 part (a)
    
    Up = zeros(n2, 1); % full vector including boundary nodes
    Up(interior) = W(1:n); % copy displacement part of the solution
    
    % plot the solution
    %running through the selected timestamps using a for loop and plotting
    %a figure for the solution at each timestamp
    for i = 1:length(timestamps)
        if ((it-1)*dt == timestamps(i))
            %creating a condition where it also plots the top-view incase the
            %timestamp is 0.3 for Q3 part (c)
            if (timestamps(i)==0.3)
                figure;
                plot_wave(xm, ym, Up);
                drawnow();
                figure;
                plot_wave(xm, ym, Up);
                view(0,90);
                drawnow();
            else
                figure;
                plot_wave(xm, ym, Up);
                drawnow();
            end
        end
    end
end

end

function plot_wave(xm, ym, U)
    clf,
    surf(xm, ym, reshape(U, size(xm)));  hold on;
    shading interp;
    axis([0, 1, 0, 1, -1, 1]);
end

